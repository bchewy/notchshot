# NotchShot 0.5.2

A local macOS utility for capturing the active app window, readable text and accessibility context into a compact notch shelf.

## Requirements

macOS 15 or newer. The prebuilt preview is for Apple silicon. Building from source requires Xcode Command Line Tools / Swift 6.

## Build and run

Run `./script/build_and_run.sh --verify` from this directory. This builds and signs the app into `outputs/NotchShot.app`. If no development signing identity is available, the script uses ad-hoc signing. This personal preview is not notarized by Apple.

## Capture

Grant Accessibility for window text and controls, and Screen Recording for window images. Press left Shift and right Shift together, or choose a shortcut in Settings. Review, copy or export your captures from the notch.

Captures stay in memory until copied or exported; quitting clears the session. App accessibility support varies, and destination apps choose which clipboard formats they accept.

## License

GPL-3.0-only. The notch panel is adapted from Notchi by sk-ruban. See LICENSE and THIRD_PARTY_NOTICES.md for code and bundled asset credits.
