enum NotchPage: Equatable {
    case shelf
    case settings
    case detail
}
